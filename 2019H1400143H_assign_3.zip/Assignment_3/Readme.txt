Description:This Kernel module identifies a USB Mass Storage attached to a computer and performs the reading and writing operation of data from and to the USB Drive respectively using the SCSI commands.

Written By: Himanshu Mathur & Adwait Rahatgaonkar

Steps to follow:-

1. Type 'make all' command, it will build main.ko

2. Remove the default USB drivers already installed in the kernel by writing the commands:
	a. sudo rmmod uas
	b. sudo rmmod usb_storage

3. Then insert the module using 'sudo insmod main.ko'

4. $ dmesg -wH to check the kernel log for device Insert, Open, Close and Remove.

5. First you need to remove the module by using 'sudo rmmod main'

6. By restarting your computer, you can reinstall the default USB Drivers already present in the kernel.
